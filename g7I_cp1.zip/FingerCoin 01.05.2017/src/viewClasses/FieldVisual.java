package viewClasses;
import javax.swing.*;
/**
 * This class creates the visual of the pitch of the Finger Coin game.
 */
public class FieldVisual extends JPanel
{
   //TO DO
}