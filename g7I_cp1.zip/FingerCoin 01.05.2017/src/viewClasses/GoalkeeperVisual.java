package viewClasses;
import java.awt.*;
import javax.swing.*;
import playground.*;
/**
 * This class creates the visual of the goalkeeper in the Finger Coin game.
 * @author Mustafa Bay
 * @version 01.05.2017
 */
public class GoalkeeperVisual extends JComponent
{
  //properties
  Goalkeeper keeper;
  
  /**
   * Constructor
   * @param difficulty is the difficulty of the game
   * @param x is the x coordinate of the Goalkeeper
   * @param y is the y coordinate of the Goalkeeper
   */
  public GoalkeeperVisual( int difficulty, int x, int y)
  {
    keeper = new Goalkeeper( difficulty, x, y);
  }
  
  /**
   * This method creates the goalkeeper's visual by painting instructions.
   * @param g includes the painting instructions.
   */
  public void paint(Graphics g) 
  {
    g.drawRect ( (int) keeper.getHeight(), (int) keeper.getWidth(), (int) keeper.getX(), (int) keeper.getY());
//    Image img = new Image("C:\Users\Mustafa\Desktop\CS Project\indir");
//    rectangle.setFill(new ImagePattern(img));
  }
  
  //This method is for test purposes only.
  public static void main(String[] args)
  {
    JFrame window = new JFrame();
    window.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    window.setBounds(30, 30, 300, 300);
    window.getContentPane().add( new GoalkeeperVisual( 2, 20, 20));
    window.setVisible(true);
  }
}