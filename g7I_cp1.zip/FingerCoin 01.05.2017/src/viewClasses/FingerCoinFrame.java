package viewClasses;
import playground.*;
import viewClasses.*;
import javax.swing.*;
/**
 * This program simulates the Finger Coin game and this class is the frame of it.
 */
public class FingerCoinFrame extends JFrame
{
   //TO DO
}