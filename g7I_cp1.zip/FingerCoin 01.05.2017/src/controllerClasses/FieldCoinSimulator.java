package controllerClasses;
import javax.swing.*;
/**
 * This class controls the "actions" of the Finger Coin game by using javax.swing.Timer and simulates the game by
 * creating instances of classes the game has.
 */
public class FieldCoinSimulator
{
   // TO DO
}